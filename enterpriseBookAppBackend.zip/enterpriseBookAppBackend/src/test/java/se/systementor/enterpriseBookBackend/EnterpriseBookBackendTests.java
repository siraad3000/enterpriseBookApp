package se.systementor.enterpriseBookBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnterpriseBookBackendTests {

	@Test
	void contextLoads() {
	}

}
