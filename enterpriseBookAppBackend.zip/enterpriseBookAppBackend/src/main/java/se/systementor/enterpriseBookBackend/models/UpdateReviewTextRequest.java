package se.systementor.enterpriseBookBackend.models;

public class UpdateReviewTextRequest {
    private int id;
    private String reviewText;

    // Getters and Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getReviewText() {
        return reviewText;
    }
    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }
}
