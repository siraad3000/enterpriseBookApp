import React from 'react';

const TemplateComponent = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome!</h1>
      <p>You have successfully logged in.</p>
    </div>
  );
};

export default TemplateComponent;
